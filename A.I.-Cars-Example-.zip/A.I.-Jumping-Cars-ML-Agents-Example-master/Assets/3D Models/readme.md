Check out https://kenney.nl/assets for more amazing 3D Models and general game assets.
