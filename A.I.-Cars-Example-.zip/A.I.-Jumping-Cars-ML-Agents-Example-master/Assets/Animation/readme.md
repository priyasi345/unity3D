These Animations just move the Scenery to make it seem like the car is moving
